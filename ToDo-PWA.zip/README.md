﻿# ToDo

A lightweight, responsive personal productivity dashboard. Tasks, custom lists, completion history, and appearance are stored in this browser with LocalStorage.

## Run and install ToDo

For a quick preview, open `index.html` in a modern browser. For app installation and offline support, serve or publish the whole folder over **HTTPS** (or `localhost` while developing); service workers and install prompts do not work from a `file://` URL.

Once ToDo is open from its HTTPS address, use the download icon in the header or the browser's **Install app** option. On Android, install from Chrome's menu. On iPhone or iPad, open the site in Safari, tap **Share**, then **Add to Home Screen**. On desktop, install from Chrome or Edge's address bar or browser menu. After the first online visit, the app shell is cached and can open offline. Tasks and saved items remain on that device and browser.

No package installation or build step is required. This project is an installable web app; app-store packages such as a standalone `.apk` or `.exe` are not included. Select the bell and allow notifications to receive a reminder when an unfinished task reaches its due date and time. The page must be open for reminders; a task that became overdue while the page was closed is reported when you reopen it.

## Included

- Create, edit, complete, reopen, and delete tasks
- Due dates and times, overdue cues, priorities, notes, and custom colored lists
- Search, priority filter, due-time/priority/creation/alphabetical sorting
- Today, upcoming, all-task, and month calendar views
- Completed-task history, including the option to reopen a task
- A separate Keepsakes area for photos, notes, and important information, stored in browser IndexedDB
- Daily completion ring and score, active streak, and weekly activity indicators
- Light and dark themes, responsive layout, keyboard shortcuts, and optional browser reminders
